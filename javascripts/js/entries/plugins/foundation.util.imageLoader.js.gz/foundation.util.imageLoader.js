import { Foundation } from './foundation.core';

import { onImagesLoaded } from '../../foundation.util.imageLoader';

Foundation.onImagesLoaded = onImagesLoaded;
