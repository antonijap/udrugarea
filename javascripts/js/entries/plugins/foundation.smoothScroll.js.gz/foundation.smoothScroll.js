import { Foundation } from './foundation.core';

import { SmoothScroll } from '../../foundation.smoothScroll';
Foundation.plugin(SmoothScroll, 'SmoothScroll');

