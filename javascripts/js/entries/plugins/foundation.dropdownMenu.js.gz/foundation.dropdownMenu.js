import { Foundation } from './foundation.core';

import { DropdownMenu } from '../../foundation.dropdownMenu';
Foundation.plugin(DropdownMenu, 'DropdownMenu');
