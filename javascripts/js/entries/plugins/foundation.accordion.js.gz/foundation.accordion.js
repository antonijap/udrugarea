import { Foundation } from './foundation.core';

import { Accordion } from '../../foundation.accordion';
Foundation.plugin(Accordion, 'Accordion');
